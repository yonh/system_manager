$(document).ready(function () {
	// Semantic UI modules.
    $('.dropdown').dropdown({
        transition: 'slide up'
    });
});